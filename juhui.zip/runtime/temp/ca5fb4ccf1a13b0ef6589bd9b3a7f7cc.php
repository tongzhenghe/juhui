<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:105:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\public/../application/admin\view\juhuiadmin\index.html";i:1568365622;s:104:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\application\admin\view\juhuiadmin\include\header.html";i:1568513816;s:102:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\application\admin\view\juhuiadmin\include\left.html";i:1568512750;s:104:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\application\admin\view\juhuiadmin\include\footer.html";i:1568365888;}*/ ?>

<body class="layui-layout-body kit-theme-default">
<div class="layui-layout layui-layout-admin">
  <!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>炬晖农业</title>
    <link rel="stylesheet" type="text/css" href="../../public/static/juhuiadmin/layui/css/layui.css" />
    <link rel="stylesheet" type="text/css" href="../../public/static/juhuiadmin/layui/css/theme/default.css" />
    <link rel="stylesheet" type="text/css" href="../../public/static/juhuiadmin/layui/css/kitadmin.css" />
</head>
<!--header-->
<div class="layui-header">
    <div class="layui-logo">
        <div class="layui-logo-toggle" kit-toggle="side" data-toggle="on">
            <i class="layui-icon">&#xe65a;</i>
        </div>
        <div class="layui-logo-brand">
            <a href="#/">炬晖</a>
        </div>
    </div>
    <div class="layui-layout-left">

    </div>
    <div class="layui-layout-right">
        <ul class="kit-nav" lay-filter="header_right">
            <li class="kit-item" kit-target="menu">
                <a href="javascript:;">
                    <i class="layui-icon layui-icon-menu-fill"></i>
                    <span>菜单管理</span>
                </a>
            </li>

            <li class="kit-item" id="ccleft">
                <a href="javascript:;">
                    <i class="layui-icon">&#xe60e;</i>
                </a>
            </li>

            <li class="kit-item" id="cc">
                <a href="javascript:;">
                    <i class="layui-icon">&#xe64c;</i>
                </a>
            </li>
            <li class="kit-item">
                <a href="javascript:;">
<span>
<img src="http://huamei.juhuiny.com/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20190616180100.png" class="layui-nav-img">Van
</span>
                </a>
                <ul class="kit-nav-child kit-nav-right">
                    <li class="kit-item">
                        <a href="#/juhui/profile">
                            <i class="layui-icon">&#xe612;</i>
                            <span>个人中心</span>
                        </a>
                    </li>
                    <li class="kit-item" kit-target="setting">
                        <a href="javascript:;">
                            <i class="layui-icon">&#xe614;</i>
                            <span>设置</span>
                        </a>
                    </li>
                    <!--<li class="kit-nav-line"></li>-->

                    <!--<li class="kit-item">-->
                        <!--<a href="temp/login.html">-->
                            <!--<i class="layui-icon">&#x1006;</i>-->
                            <!--<span>注销</span>-->
                        <!--</a>-->
                    <!--</li>-->
                </ul>
            </li>
        </ul>
    </div>
</div>
<!--header-End-->
  
<!--left-->
<div class="layui-side" kit-side="true">
    <div class="layui-side-scroll">
        <div id="menu-box">
            <ul class="kit-menu">
                <li class="kit-menu-item">
                    <a href="#/">
                        <i class="layui-icon"></i>
                        <span>首页</span>
                    </a>
                </li>
                <li class="kit-menu-item layui-show">
                    <a href="javascript:;">
                        <i class="layui-icon"></i>
                        <span>Layui组件</span>
                    </a>
                    <ul class="kit-menu-child layui-anim layui-anim-upbit">
                        <li class="kit-menu-item">
                            <a href="#/juhui/grid">
                                <i class="layui-icon"></i>
                                <span>Grid</span>
                            </a>
                        </li>
                        <li class="kit-menu-item">
                            <a href="javascript:;">
                                <i class="layui-icon"></i>
                                <span>基本元素</span>
                            </a>
                            <ul class="kit-menu-child layui-anim layui-anim-upbit">
                                <li class="kit-menu-item">
                                    <a href="#/juhui/button">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>按钮</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/form">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>表单</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/nav">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>导航/面包屑</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/tab">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>选项卡</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/progress">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>进度条</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/panel">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>面板</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/badge">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>徽章</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/timeline">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>时间线</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/table_element">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>静态表格</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/anim">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>动画</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/auxiliar">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>辅助元素</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="kit-menu-item layui-show">
                            <a href="javascript:;">
                                <i class="layui-icon"></i>
                                <span>组件</span>
                            </a>
                            <ul class="kit-menu-child layui-anim layui-anim-upbit">
                                <li class="kit-menu-item">
                                    <a href="#/juhui/layer">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>弹出层</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/laydate">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>日期与时间</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/table">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>数据表格</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/laypage">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>分页</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/upload">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>文件上传</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/carousel">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>轮训</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/laytpl">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>模板引擎</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/flow">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>流加载</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/util">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>工具集</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="#/juhui/code">
                                        <i class="layui-icon">&#xe62e;</i>
                                        <span>代码修饰器</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="kit-menu-item">
                    <a href="javascript:;">
                        <i class="layui-icon"></i>
                        <span>组件</span>
                    </a>
                    <ul class="kit-menu-child layui-anim layui-anim-upbit">
                        <li class="kit-menu-item">
                            <a href="#/juhui/select">
                                <i class="layui-icon"></i>
                                <span>Select</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="kit-menu-item">
                    <a href="javascript:;">
                        <i class="layui-icon"></i>
                        <span>异常页</span>
                    </a>
                    <ul class="kit-menu-child layui-anim layui-anim-upbit">
                        <li class="kit-menu-item">
                            <a href="#/juhui/403">
                                <i class="layui-icon">&#xe69c;</i>
                                <span>403</span>
                            </a>
                        </li>
                        <li class="kit-menu-item">
                            <a href="#/juhui/404">
                                <i class="layui-icon">&#xe61c;</i>
                                <span>404</span>
                            </a>
                        </li>
                        <li class="kit-menu-item">
                            <a href="#/juhui/500">
                                <i class="layui-icon">&#xe64d;</i>
                                <span>500</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="kit-menu-item">
                    <a href="javascript:;" class="child">
                        <i class="layui-icon"></i>
                        <span>多级菜单</span>
                    </a>
                    <ul class="kit-menu-child kit-menu-child layui-anim layui-anim-upbit">
                        <li class="kit-menu-item">
                            <a href="#/juhui/form">
                                <i class="layui-icon"></i>
                                <span>二级菜单1</span>
                            </a>
                        </li>
                        <li class="kit-menu-item">
                            <a href="javascript:;" class="child">
                                <i class="layui-icon"></i>
                                <span>二级菜单2</span>
                            </a>
                            <ul class="kit-menu-child kit-menu-child layui-anim layui-anim-upbit">
                                <li class="kit-menu-item">
                                    <a href="https://www.baidu.com" target="_blank">
                                        <i class="layui-icon"></i>
                                        <span>三级菜单1</span>
                                    </a>
                                </li>
                                <li class="kit-menu-item">
                                    <a href="javascript:;" >
                                        <i class="layui-icon"></i>
                                        <span>三级菜单2</span>
                                    </a>
                                    <ul class="kit-menu-child kit-menu-child layui-anim layui-anim-upbit">
                                        <li class="kit-menu-item">
                                            <a href="https://www.baidu.com" target="_blank">
                                                <i class="layui-icon"></i>
                                                <span>四级菜单1</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="kit-menu-item">
                    <a href="javascript:;" class="child">
                        <i class="layui-icon"></i>
                        <span>API文档</span>
                    </a>
                    <ul class="kit-menu-child layui-anim layui-anim-upbit">
                        <li class="kit-menu-item">
                            <a href="#/juhui/mockjs">
                                <i class="layui-icon"></i>
                                <span>拦截器(Mockjs)</span>
                            </a>
                        </li>
                        <li class="kit-menu-item">
                            <a href="#/juhui/menu">
                                <i class="layui-icon"></i>
                                <span>左侧菜单(Menu)</span>
                            </a>
                        </li>
                        <li class="kit-menu-item">
                            <a href="#/juhui/route">
                                <i class="layui-icon"></i>
                                <span>路由配置(Route)</span>
                            </a>
                        </li>
                        <li class="kit-menu-item">
                            <a href="#/juhui/tabs">
                                <i class="layui-icon"></i>
                                <span>选项卡(Tabs)</span>
                            </a>
                        </li>
                        <li class="kit-menu-item">
                            <a href="#/juhui/utils">
                                <i class="layui-icon"></i>
                                <span>工具包(Utils)</span>
                            </a>
                        </li>
                        <li class="kit-menu-item layui-show">
                            <a href="javascript:;" class="child">
                                <i class="layui-icon"></i>
                                <span>组件(Component)</span>
                            </a>
                            <ul class="kit-menu-child kit-menu-child layui-anim layui-anim-upbit">
                                <li class="kit-menu-item">
                                    <a href="#/juhui/nav">
                                        <i class="layui-icon"></i>
                                        <span>导航栏(Nav)</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="kit-menu-item">
                    <a href="https://www.baidu.com" target="_blank">
                        <i class="layui-icon"></i>
                        <span>外链百度一</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
<!--left-End-->

  <!--body-->
  <div class="layui-body" kit-body="true">
    <router-view></router-view>
  </div>
  <!--body-End-->
  
<!--footer-->
<div class="layui-footer" kit-footer="true">
    2017 © kit.zhengjinfan.cn MIT license
    <div style="width:400px; height:400px;" class="load-container load1">
        <div class="loader">Loading...</div>
    </div>
</div>
<!--footer-End-->
<script type="text/javascript" src="../../public/static/juhuiadmin/layui/polyfill.min.js"></script>
<script type="text/javascript" src="../../public/static/juhuiadmin/layui/layui.js"></script>
<script type="text/javascript" src="../../public/static/juhuiadmin/layui/kitadmin.js"></script>
<script type="text/javascript" src="../../public/static/juhuiadmin/layui/mockjs-config.js"></script>
<script type="text/javascript" src="../../public/static/juhuiadmin/layui/echarts.min.js"></script>
<script>layui.use("admin");</script>
<script type="text/javascript" src="../../public/static/juhuiadmin/layui/lay/modules/jquery.js"></script>
</div>
</body>