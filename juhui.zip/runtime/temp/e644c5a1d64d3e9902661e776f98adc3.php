<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:103:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\public/../application/admin\view\juhuiadmin\nav.html";i:1533258940;}*/ ?>
<div class="layui-fluid">
  <div class="layui-row">
    <div class="layui-col-xs12">
      <div class="layui-card">
        <div class="layui-card-header">导航/面包屑-> 文档请参考：
          <a href="http://www.layui.com/doc/element/nav.html" target="_blank">
          http://www.layui.com/doc/element/nav.html
        </a>
        </div>
        <div class="layui-card-body">


          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
            <legend>水平导航菜单</legend>
          </fieldset>

          <ul class="layui-nav">
            <li class="layui-nav-item"><a href="">最新活动</a></li>
            <li class="layui-nav-item layui-this">
              <a href="javascript:;">产品</a>
              <dl class="layui-nav-child">
                <dd><a href="">选项1</a></dd>
                <dd><a href="">选项2</a></dd>
                <dd><a href="">选项3</a></dd>
              </dl>
            </li>
            <li class="layui-nav-item"><a href="">大数据</a></li>
            <li class="layui-nav-item">
              <a href="javascript:;">解决方案</a>
              <dl class="layui-nav-child">
                <dd><a href="">移动模块</a></dd>
                <dd><a href="">后台模版</a></dd>
                <dd class="layui-this"><a href="">选中项</a></dd>
                <dd><a href="">电商平台</a></dd>
              </dl>
            </li>
            <li class="layui-nav-item"><a href="">社区</a></li>
          </ul>
          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
            <legend>导航带徽章和图片</legend>
          </fieldset>

          <ul class="layui-nav">
            <li class="layui-nav-item">
              <a href="">控制台<span class="layui-badge">9</span></a>
            </li>
            <li class="layui-nav-item">
              <a href="">个人中心<span class="layui-badge-dot"></span></a>
            </li>
            <li class="layui-nav-item" lay-unselect="">
              <a href="javascript:;"><img src="http://t.cn/RCzsdCq" class="layui-nav-img">我</a>
              <dl class="layui-nav-child">
                <dd><a href="javascript:;">修改信息</a></dd>
                <dd><a href="javascript:;">安全管理</a></dd>
                <dd><a href="javascript:;">退了</a></dd>
              </dl>
            </li>
          </ul>

          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
            <legend>更多导航主题</legend>
          </fieldset>

          <ul class="layui-nav layui-bg-cyan">
            <li class="layui-nav-item"><a href="">藏青导航</a></li>
            <li class="layui-nav-item layui-this"><a href="">产品</a></li>
            <li class="layui-nav-item"><a href="">大数据</a></li>
            <li class="layui-nav-item">
              <a href="javascript:;">解决方案</a>
              <dl class="layui-nav-child">
                <dd><a href="">移动模块</a></dd>
                <dd><a href="">后台模版</a></dd>
                <dd><a href="">电商平台</a></dd>
              </dl>
            </li>
            <li class="layui-nav-item"><a href="">社区</a></li>
          </ul>
          <br>
          <ul class="layui-nav layui-bg-green">
            <li class="layui-nav-item"><a href="">墨绿导航</a></li>
            <li class="layui-nav-item layui-this"><a href="">产品</a></li>
            <li class="layui-nav-item"><a href="">大数据</a></li>
            <li class="layui-nav-item">
              <a href="javascript:;">解决方案</a>
              <dl class="layui-nav-child">
                <dd><a href="">移动模块</a></dd>
                <dd><a href="">后台模版</a></dd>
                <dd><a href="">电商平台</a></dd>
              </dl>
            </li>
            <li class="layui-nav-item"><a href="">社区</a></li>
          </ul>
          <br>
          <ul class="layui-nav layui-bg-blue">
            <li class="layui-nav-item"><a href="">艳蓝导航</a></li>
            <li class="layui-nav-item layui-this"><a href="">产品</a></li>
            <li class="layui-nav-item"><a href="">大数据</a></li>
            <li class="layui-nav-item">
              <a href="javascript:;">解决方案</a>
              <dl class="layui-nav-child">
                <dd><a href="">移动模块</a></dd>
                <dd><a href="">后台模版</a></dd>
                <dd><a href="">电商平台</a></dd>
              </dl>
            </li>
            <li class="layui-nav-item"><a href="">社区</a></li>
          </ul>

          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
            <legend>垂直导航菜单</legend>
          </fieldset>

          <ul class="layui-nav layui-nav-tree layui-inline" lay-filter="demo_hash" style="margin-right: 10px;">
            <li class="layui-nav-item layui-nav-itemed">
              <a href="javascript:;">默认展开</a>
              <dl class="layui-nav-child">
                <dd><a href="javascript:;">选项一</a></dd>
                <dd><a href="javascript:;">选项二</a></dd>
                <dd><a href="javascript:;">选项三</a></dd>
                <dd><a href="">跳转项</a></dd>
              </dl>
            </li>
            <li class="layui-nav-item">
              <a href="javascript:;">解决方案</a>
              <dl class="layui-nav-child">
                <dd><a href="">移动模块</a></dd>
                <dd><a href="">后台模版</a></dd>
                <dd><a href="">电商平台</a></dd>
              </dl>
            </li>
            <li class="layui-nav-item"><a href="">云市场</a></li>
            <li class="layui-nav-item"><a href="">社区</a></li>
          </ul>
          <ul class="layui-nav layui-nav-tree layui-bg-cyan layui-inline" lay-filter="demo_hash">
            <li class="layui-nav-item layui-nav-itemed">
              <a href="javascript:;">默认展开</a>
              <dl class="layui-nav-child">
                <dd><a href="javascript:;">选项一</a></dd>
                <dd><a href="javascript:;">选项二</a></dd>
                <dd><a href="javascript:;">选项三</a></dd>
                <dd><a href="">跳转项</a></dd>
              </dl>
            </li>
            <li class="layui-nav-item">
              <a href="javascript:;">解决方案</a>
              <dl class="layui-nav-child">
                <dd><a href="">移动模块</a></dd>
                <dd><a href="">后台模版</a></dd>
                <dd><a href="">电商平台</a></dd>
              </dl>
            </li>
            <li class="layui-nav-item"><a href="">云市场</a></li>
            <li class="layui-nav-item"><a href="">社区</a></li>
          </ul>

          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 50px;">
            <legend>侧边固定导航菜单</legend>
          </fieldset>

          ← 囖，就左边那家伙！ 带图标神马的那是必须可以的。另外你可能还需要下拉菜单，这个将在下版本推出！

          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 50px;">
            <legend>默认面包屑</legend>
          </fieldset>

          <span class="layui-breadcrumb">
    <a href="/">首页</a>
    <a href="/demo_hash/">演示</a>
    <a><cite>导航元素</cite></a>
  </span>

          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 50px;">
            <legend>自定义分隔符的面包屑</legend>
          </fieldset>

          <span class="layui-breadcrumb" lay-separator="—">
    <a href="">首页</a>
    <a href="">国际新闻</a>
    <a href="">亚太地区</a>
    <a><cite>正文</cite></a>
  </span>

          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 50px;">
            <legend>还可以用于门户频道的面包屑</legend>
          </fieldset>

          <span class="layui-breadcrumb" lay-separator="|">
    <a href="">娱乐</a>
    <a href="">八卦</a>
    <a href="">体育</a>
    <a href="">搞笑</a>
    <a href="">视频</a>
    <a href="">游戏</a>
    <a href="">综艺</a>
  </span>

          <p class="layui-elem-quote">其实就是自定义了个“|”的分隔符，然后最后一项也可以点。</p>

        </div>
      </div>
    </div>
  </div>
</div>


<script>
  layui.use('element', function() {
    var element = layui.element; //导航的hover效果、二级菜单等功能，需要依赖element模块

    element.init();

    //监听导航点击
    element.on('nav(demo_hash)', function(elem) {
      //console.log(elem)
      layer.msg(elem.text());
    });
  });
</script>

<style scoped>

</style>