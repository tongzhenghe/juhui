<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:106:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\public/../application/admin\view\juhuiadmin\laytpl.html";i:1533258940;}*/ ?>
<div class="layui-fluid">
  <div class="layui-row">
    <div class="layui-col-xs12">
      <div class="layui-card">
        <div class="layui-card-header">模块引擎-> 文档请参考：
          <a href="http://www.layui.com/doc/modules/laytpl.html" target="_blank">
            <span>http://www.layui.com/doc/modules/laytpl.html</span>
          </a>
        </div>
        <div class="layui-card-body">
          <a href="http://www.layui.com/demo/laytpl.html" target="_blank">
            <span>点击查看官方演示</span>
          </a>
        </div>
      </div>
    </div>
  </div>
</div>


<script>
</script>

<style scoped>

</style>