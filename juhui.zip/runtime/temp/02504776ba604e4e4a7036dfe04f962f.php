<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:106:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\public/../application/admin\view\juhuiadmin\select.html";i:1533258940;}*/ ?>
<div class="layui-fluid">
  <div class="layui-row">
    <div class="layui-col-xs12">
      <div class="layui-card">
        <div class="layui-card-header">Select component</div>
        <div class="layui-card-body">
          <select class="kit-select-target">
            <option value="#1">#1</option>
            <option value="#1">#2</option>
            <option value="#1">#3</option>
            <option value="#1">#4</option>
            <option value="#1">#5</option>
          </select>
          <!-- <div class="kit-select">
            <div class="kit-select-render">
              <div class="kit-select-input">
                <ul class="kit-select-tags">
                  <li class="kit-item">
                    <a href="javascript:;">
                      <span>#1xx</span>
                      <i class="layui-icon">&#x1006;</i>
                    </a>
                  </li>
                  <li class="kit-item">
                    <a href="javascript:;">
                      <span>#1xx</span>
                      <i class="layui-icon">&#x1006;</i>
                    </a>
                  </li>
                  <li class="kit-item">
                    <a href="javascript:;">
                      <span>#1xx</span>
                      <i class="layui-icon">&#x1006;</i>
                    </a>
                  </li>
                  <li class="kit-item">
                    <a href="javascript:;">
                      <span>#1xx</span>
                      <i class="layui-icon">&#x1006;</i>
                    </a>
                  </li>
                  <li class="kit-item">
                    <a href="javascript:;">
                      <span>#1xx</span>
                      <i class="layui-icon">&#x1006;</i>
                    </a>
                  </li>
                  <li class="kit-item">
                    <a href="javascript:;">
                      <span>#1xx</span>
                      <i class="layui-icon">&#x1006;</i>
                    </a>
                  </li>
                  <li class="kit-item">
                    <a href="javascript:;">
                      <span>#1xx</span>
                      <i class="layui-icon">&#x1006;</i>
                    </a>
                  </li>
                  <li class="kit-item">
                    <input />
                  </li>
                </ul>
              </div>
              <ul class="kit-select-dropdown">
                <li class="kit-item">
                  <a href="javascript:;">#xxx</a>
                </li>
                <li class="kit-item">
                  <a href="javascript:;">#xxx</a>
                </li>
                <li class="kit-item">
                  <a href="javascript:;">#xxx</a>
                </li>
                <li class="kit-item">
                  <a href="javascript:;">#xxx</a>
                </li>
              </ul>
            </div>
          </div> -->
        </div>
      </div>
    </div>
  </div>
</div>
<script>
  layui.use(['select'], function () {
    var layer = layui.layer,
      $ = layui.jquery,
      select = layui.select;

      select.render();
  });
</script>
<style scoped>
</style>