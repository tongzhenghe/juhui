<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:104:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\public/../application/admin\view\juhuiadmin\grid.html";i:1533258940;}*/ ?>
<div class="layui-fluid">
  <div class="layui-row">
    <div class="layui-col-xs12">
      <div class="layui-card">
        <div class="layui-card-header">栅格Grid-> 文档请参考：
          <a href="http://www.layui.com/doc/element/layout.html" target="_blank">
            <span>http://www.layui.com/doc/element/layout.html</span>
          </a>
        </div>
        <div class="layui-card-body site-demo">

          <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
          <!--[if lt IE 9]>
  <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
  <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

          <div class="layui-container">
            <blockquote class="layui-elem-quote">注意：下述演示中的颜色只是做一个区分作用，并非栅格内置。</blockquote>

            <fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
              <legend>始终等比例水平排列</legend>
            </fieldset>

            <div class="layui-row">
              <div class="layui-col-xs6">
                <div class="grid-demo grid-demo-bg1">6/12</div>
              </div>
              <div class="layui-col-xs6">
                <div class="grid-demo">6/12</div>
              </div>
            </div>
            <div class="layui-row">
              <div class="layui-col-xs3">
                <div class="grid-demo grid-demo-bg1">3/12</div>
              </div>
              <div class="layui-col-xs3">
                <div class="grid-demo">3/12</div>
              </div>
              <div class="layui-col-xs3">
                <div class="grid-demo grid-demo-bg1">3/12</div>
              </div>
              <div class="layui-col-xs3">
                <div class="grid-demo">3/12</div>
              </div>
            </div>

            <fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
              <legend>移动设备、桌面端的组合响应式展现</legend>
            </fieldset>

            <div class="layui-row">
              <div class="layui-col-xs12 layui-col-md8">
                <div class="grid-demo grid-demo-bg1">移动：12/12、桌面：8/12</div>
              </div>
              <div class="layui-col-xs6 layui-col-md4">
                <div class="grid-demo">移动：6/12、桌面：4/12</div>
              </div>
              <div class="layui-col-xs6 layui-col-md12">
                <div class="grid-demo grid-demo-bg2">移动：6/12、桌面：12/12</div>
              </div>
            </div>

            <fieldset class="layui-elem-field layui-field-title" style="margin-top: 50px;">
              <legend>移动设备、平板、桌面端的复杂组合响应式展现</legend>
            </fieldset>

            <div class="layui-row">
              <div class="layui-col-xs6 layui-col-sm6 layui-col-md4">
                <div class="grid-demo grid-demo-bg1">移动：6/12 | 平板：6/12 | 桌面：4/12</div>
              </div>
              <div class="layui-col-xs6 layui-col-sm6 layui-col-md4">
                <div class="grid-demo layui-bg-red">移动：6/12 | 平板：6/12 | 桌面：4/12</div>
              </div>
              <div class="layui-col-xs4 layui-col-sm12 layui-col-md4">
                <div class="grid-demo layui-bg-blue">移动：4/12 | 平板：12/12 | 桌面：4/12</div>
              </div>
              <div class="layui-col-xs4 layui-col-sm7 layui-col-md8">
                <div class="grid-demo layui-bg-green">移动：4/12 | 平板：7/12 | 桌面：8/12</div>
              </div>
              <div class="layui-col-xs4 layui-col-sm5 layui-col-md4">
                <div class="grid-demo layui-bg-black">移动：4/12 | 平板：5/12 | 桌面：4/12</div>
              </div>
            </div>

            <fieldset class="layui-elem-field layui-field-title" style="margin-top: 50px;">
              <legend>常规布局：从小屏幕堆叠到桌面水平排列</legend>
            </fieldset>

            <div class="layui-row">
              <div class="layui-col-md1">
                <div class="grid-demo grid-demo-bg1">1/12</div>
              </div>
              <div class="layui-col-md1">
                <div class="grid-demo">1/12</div>
              </div>
              <div class="layui-col-md1">
                <div class="grid-demo grid-demo-bg1">1/12</div>
              </div>
              <div class="layui-col-md1">
                <div class="grid-demo">1/12</div>
              </div>
              <div class="layui-col-md1">
                <div class="grid-demo grid-demo-bg1">1/12</div>
              </div>
              <div class="layui-col-md1">
                <div class="grid-demo">1/12</div>
              </div>
              <div class="layui-col-md1">
                <div class="grid-demo grid-demo-bg1">1/12</div>
              </div>
              <div class="layui-col-md1">
                <div class="grid-demo">1/12</div>
              </div>
              <div class="layui-col-md1">
                <div class="grid-demo grid-demo-bg1">1/12</div>
              </div>
              <div class="layui-col-md1">
                <div class="grid-demo">1/12</div>
              </div>
              <div class="layui-col-md1">
                <div class="grid-demo grid-demo-bg1">1/12</div>
              </div>
              <div class="layui-col-md1">
                <div class="grid-demo">1/12</div>
              </div>
            </div>

            <div class="layui-row">
              <div class="layui-col-md9">
                <div class="grid-demo grid-demo-bg1">75%</div>
              </div>
              <div class="layui-col-md3">
                <div class="grid-demo">25%</div>
              </div>
            </div>

            <div class="layui-row">
              <div class="layui-col-md4">
                <div class="grid-demo grid-demo-bg1">33.33%</div>
              </div>
              <div class="layui-col-md4">
                <div class="grid-demo">33.33%</div>
              </div>
              <div class="layui-col-md4">
                <div class="grid-demo grid-demo-bg1">33.33%</div>
              </div>
            </div>

            <div class="layui-row">
              <div class="layui-col-md6">
                <div class="grid-demo grid-demo-bg1">50%</div>
              </div>
              <div class="layui-col-md6">
                <div class="grid-demo">50%</div>
              </div>
            </div>

            <fieldset class="layui-elem-field layui-field-title" style="margin-top: 50px;">
              <legend>列间隔</legend>
            </fieldset>

            <div class="layui-row layui-col-space1">
              <div class="layui-col-md3">
                <div class="grid-demo grid-demo-bg1">1/4</div>
              </div>
              <div class="layui-col-md3">
                <div class="grid-demo">1/4</div>
              </div>
              <div class="layui-col-md3">
                <div class="grid-demo grid-demo-bg1">1/4</div>
              </div>
              <div class="layui-col-md3">
                <div class="grid-demo">1/4</div>
              </div>
            </div>

            <div class="layui-row layui-col-space5">
              <div class="layui-col-md4">
                <div class="grid-demo grid-demo-bg1">1/3</div>
              </div>
              <div class="layui-col-md4">
                <div class="grid-demo">1/3</div>
              </div>
              <div class="layui-col-md4">
                <div class="grid-demo grid-demo-bg1">1/3</div>
              </div>
            </div>

            <div class="layui-row layui-col-space10">
              <div class="layui-col-md9">
                <div class="grid-demo grid-demo-bg1">9/12</div>
              </div>
              <div class="layui-col-md3">
                <div class="grid-demo">3/12</div>
              </div>
            </div>

            <div class="layui-row layui-col-space15">
              <div class="layui-col-md7">
                <div class="grid-demo grid-demo-bg1">7/12</div>
              </div>
              <div class="layui-col-md5">
                <div class="grid-demo">5/12</div>
              </div>
            </div>

            <div class="layui-row layui-col-space30">
              <div class="layui-col-md7">
                <div class="grid-demo grid-demo-bg1">7/12</div>
              </div>
              <div class="layui-col-md5">
                <div class="grid-demo">5/12</div>
              </div>
            </div>

            <fieldset class="layui-elem-field layui-field-title" style="margin-top: 50px;">
              <legend>列偏移</legend>
            </fieldset>

            <div class="layui-row">
              <div class="layui-col-md4">
                <div class="grid-demo grid-demo-bg1">4/12</div>
              </div>
              <div class="layui-col-md4 layui-col-md-offset4">
                <div class="grid-demo">偏移4列</div>
              </div>
              <div class="layui-col-md1 layui-col-md-offset5">
                <div class="grid-demo grid-demo-bg1">偏移5列</div>
              </div>
              <div class="layui-col-md1">
                <div class="grid-demo">不偏移</div>
              </div>
            </div>

            <div class="layui-row">
              <div class="layui-col-md3 layui-col-md-offset3">
                <div class="grid-demo grid-demo-bg1">偏移3列</div>
              </div>
              <div class="layui-col-md3 layui-col-md-offset1">
                <div class="grid-demo">偏移1列</div>
              </div>
            </div>

            <fieldset class="layui-elem-field layui-field-title" style="margin-top: 50px;">
              <legend>栅格嵌套</legend>
            </fieldset>

            <div class="layui-row">
              <div class="layui-col-md5">
                <div class="layui-row grid-demo">
                  <div class="layui-col-md3">
                    <div class="grid-demo grid-demo-bg1">内部列</div>
                  </div>
                  <div class="layui-col-md9">
                    <div class="grid-demo grid-demo-bg2">内部列</div>
                  </div>
                  <div class="layui-col-md12">
                    <div class="grid-demo grid-demo-bg3">内部列</div>
                  </div>
                </div>
              </div>
              <div class="layui-col-md7">
                <div class="layui-row grid-demo grid-demo-bg1">
                  <div class="layui-col-md12">
                    <div class="grid-demo">内部列</div>
                  </div>
                  <div class="layui-col-md9">
                    <div class="grid-demo grid-demo-bg2">内部列</div>
                  </div>
                  <div class="layui-col-md3">
                    <div class="grid-demo grid-demo-bg3">内部列</div>
                  </div>
                </div>
              </div>
            </div>

          </div>

          <div class="layui-fluid">
            <fieldset class="layui-elem-field layui-field-title">
              <legend>流体容器（宽度自适应，不固定）</legend>
            </fieldset>
            <div class="layui-row">
              <div class="layui-col-sm3">
                <div class="grid-demo grid-demo-bg1">25%</div>
              </div>
              <div class="layui-col-sm3">
                <div class="grid-demo">25%</div>
              </div>
              <div class="layui-col-sm3">
                <div class="grid-demo grid-demo-bg1">25%</div>
              </div>
              <div class="layui-col-sm3">
                <div class="grid-demo">25%</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<script>
</script>

<style scoped>
  .site-demo .layui-row {
    margin-bottom: 10px;
  }
  
  .grid-demo {
    padding: 10px;
    line-height: 50px;
    text-align: center;
    background-color: #79C48C;
    color: #fff;
  }
  
  .grid-demo-bg1 {
    background-color: #63BA79;
  }
  .grid-demo-bg2 {
    background-color: #49A761;
  }
</style>