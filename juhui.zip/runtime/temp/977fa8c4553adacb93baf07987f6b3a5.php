<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:111:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\public/../application/admin\view\juhuiadmin\inputnumber.html";i:1533117590;}*/ ?>
<div class="layui-fluid">
  <div class="layui-row">
    <div class="layui-col-xs12">
      <input type="text" class="layui-input kit-in" kit-in-precision="1" value="1" style="width:135px;" kit-target="inputnumber" max="100" min="0" />
    </div>
    <div class="layui-col-xs12">
      <input type="text" class="layui-input kit-in" kit-in-precision="5" kit-in-type="double"  value="1" style="width:100px;" kit-target="inputnumber" max="100" min="0" />
    </div>
  </div>
</div>
<script>
  layui.config({
    base: '/js/'
  }).use(['inputnumber'], function() {
    layui.inputnumber.set({
      onClicked: function(data) {
        console.log(data);
      }
    }).render();
  });
</script>
<style scoped>

</style>