<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:104:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\public/../application/admin\view\juhuiadmin\code.html";i:1533258940;}*/ ?>
<div class="layui-fluid">
  <div class="layui-row">
    <div class="layui-col-xs12">
      <div class="layui-card">
        <div class="layui-card-header">代码修饰器-> 文档请参考：
          <a href="http://www.layui.com/doc/modules/code.html" target="_blank">
            <span>http://www.layui.com/doc/modules/code.html</span>
          </a>
        </div>
        <div class="layui-card-body">

          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
            <legend>默认修饰</legend>
          </fieldset>

          <pre class="layui-code">//在里面存放任意的代码
Lay.fn.event = function(modName, events, params){
  var that = this, result = null, filter = events.match(/\(.*\)$/)||[];
  var set = (events = modName + '.'+ events).replace(filter, ''); 
};</pre>

          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 50px;">
            <legend>notepad风格</legend>
          </fieldset>

          <pre class="layui-code" lay-title="JavaScript" lay-skin="notepad">//代码区域
Lay.fn.event = function(modName, events, params){
  var that = this, result = null, filter = events.match(/\(.*\)$/)||[];
  var set = (events = modName + '.'+ events).replace(filter, ''); 
};</pre>
          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 50px;">
            <legend>代码中的代码</legend>
          </fieldset>

          <pre class="layui-code">//代码区域
              Lay.fn.event = function(modName, events, params){
                var that = this, result = null, filter = events.match(/\(.*\)$/)||[];
                var set = (events = modName + '.'+ events).replace(filter, ''); 
              };
                    <pre class="layui-code">//代码区域
              Lay.fn.event = function(modName, events, params){
                var that = this, result = null, filter = events.match(/\(.*\)$/)||[];
                var set = (events = modName + '.'+ events).replace(filter, ''); 
              };
                    </pre>
          </pre>

          <pre class="layui-code" lay-skin="notepad">//代码区域
              Lay.fn.event = function(modName, events, params){
                var that = this, result = null, filter = events.match(/\(.*\)$/)||[];
                var set = (events = modName + '.'+ events).replace(filter, ''); 
              };
                    <pre class="layui-code" lay-skin="notepad">//代码区域
              Lay.fn.event = function(modName, events, params){
                var that = this, result = null, filter = events.match(/\(.*\)$/)||[];
                var set = (events = modName + '.'+ events).replace(filter, ''); 
              };
              <pre class="layui-code" lay-skin="notepad">//代码区域
              Lay.fn.event = function(modName, events, params){
                var that = this, result = null, filter = events.match(/\(.*\)$/)||[];
                var set = (events = modName + '.'+ events).replace(filter, ''); 
              };
              <pre class="layui-code" lay-skin="notepad">//代码区域
              Lay.fn.event = function(modName, events, params){
                var that = this, result = null, filter = events.match(/\(.*\)$/)||[];
                var set = (events = modName + '.'+ events).replace(filter, ''); 
              };
              <pre class="layui-code" lay-skin="notepad">//代码区域
              Lay.fn.event = function(modName, events, params){
                var that = this, result = null, filter = events.match(/\(.*\)$/)||[];
                var set = (events = modName + '.'+ events).replace(filter, ''); 
              };
                    </pre>
          </pre>
          </pre>
          </pre>
          </pre>

          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 50px;">
            <legend>固定高度</legend>
          </fieldset>

          <pre class="layui-code" lay-height="150px">//代码区域
              Lay.fn.event = function(modName, events, params){
                var that = this, result = null, filter = events.match(/\(.*\)$/)||[]; //提取事件过滤器
                var set = (events = modName + '.'+ events).replace(filter, ''); //获取事件本体名
                var callback = function(_, item){
                  var res = item &amp;&amp; item.call(that, params);
                  res === false &amp;&amp; result === null &amp;&amp; (result = false);
                };
                layui.each(config.event[set], callback);
                filter[0] &amp;&amp; layui.each(config.event[events], callback); //执行过滤器中的事件
                return result;
              };
                    </pre>
        </div>
      </div>
    </div>
  </div>
</div>


<script>
  layui.use('code', function() {

    layui.code(); //实际使用时，执行该方法即可。而此处注释是因为修饰器在别的js中已经执行过了
  });
</script>

<style scoped>

</style>