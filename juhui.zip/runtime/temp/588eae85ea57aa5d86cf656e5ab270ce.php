<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:107:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\public/../application/admin\view\juhuiadmin\profile.html";i:1533117594;}*/ ?>
<div class="layui-fluid">
  <div class="layui-row">
    <div class="layui-col-xs12">
      <div class="layui-card">
        <div class="layui-card-header">
          <p>个人中心</p>
        </div>
        <div class="layui-card-body">
          <h1>个人中心</h1>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
</script>
<style scoped>

</style>