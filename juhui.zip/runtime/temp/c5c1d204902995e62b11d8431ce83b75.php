<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:106:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\public/../application/admin\view\juhuiadmin\table2.html";i:1568365059;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
ss
</body>
</html>