<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:107:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\public/../application/admin\view\juhuiadmin\setting.html";i:1568512589;}*/ ?>
<div class="layui-fluid">
  <div class="layui-row">
    <div class="layui-col-xs12">
      <form class="layui-form" action="">
        <input type="radio" name="loadType" lay-filter="loadType_hash" data-id="spa_hash" value="SPA" title="单页面方式" checked>
        <input type="radio" name="loadType" lay-filter="loadType_hash" data-id="tabs_hash" value="TABS" title="选择卡方式">
      </form>
    </div>
  </div>
</div>

<script>

  layui.use(['form', 'utils'], function() {
    var form = layui.form,
      $ = layui.jquery,
      utils = layui.utils,
      localStorage = utils.localStorage;

    form.render();
    var key = 'KITADMIN_SETTING_LOADTYPE';
    var setting = localStorage.getItem(key);
    if (setting !== null) {
      if (setting.loadType === 'SPA') {
        $('input[data-id="spa_hash"]')[0].checked = true;
      } else {
        $('input[data-id="tabs_hash"]')[0].checked = true;
      }
      form.render('radio');
    }
    form.on('radio(loadType_hash)', function(data) {
      var val = data.value;
      localStorage.setItem(key, {
        loadType: val
      });
      // 重新加载
      location.reload();
    });
    var themeKey = 'KITADMIN_SETTING_THEME';
    $('input[name="setting-theme"]').on('click', function() {
      var _that = $(this);
      var themeName = _that.parent('label').attr('data-theme');
      localStorage.setItem(themeKey, {
        theme: themeName
      });
      var str = $('#theme').attr('href'); //str.substr(0,str.lastIndexOf('/')+1)
      var _themeUrl = str.substr(0, str.lastIndexOf('/') + 1);
      console.log(_themeUrl)
      $('#theme').attr('href', _themeUrl + themeName + '.css');
      var _body = $('body');
      if (!_body.hasClass('kit-theme-' + themeName)) {
        _body.addClass('kit-theme-' + themeName);
      }
    });
  });
</script>