<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:103:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\public/../application/admin\view\juhuiadmin\403.html";i:1533258934;}*/ ?>
<div class="layui-fluid">
  <div class="layui-row">
    <div class="layui-col-xs12">
      <div class="layui-row">
        <div class="layui-col-md4">&nbsp;</div>
        <div class="layui-col-md4">
          <div class="kit-exception">
            <i class="layui-icon kit-exception-icon">&#xe69c;</i>
            <h3 class="kit-exception-title">:>403 抱歉，你无权访问该页面.</h3>
            <a href="javascript:history.back(-1);" class="layui-btn">返回上一页</a>
          </div>
        </div>
        <div class="layui-col-md4">&nbsp;</div>
      </div>
    </div>
  </div>
</div>
<script>
</script>
<style scoped>

</style>