<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:108:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\public/../application/admin\view\juhuiadmin\auxiliar.html";i:1533258940;}*/ ?>
<div class="layui-fluid">
  <div class="layui-row">
    <div class="layui-col-xs12">
      <div class="layui-card">
        <div class="layui-card-header">辅助元素-> 文档请参考：
          <a href="http://www.layui.com/doc/element/auxiliar.html" target="_blank">
            <span>http://www.layui.com/doc/element/auxiliar.html</span>
          </a>
        </div>
        <div class="layui-card-body">

          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
            <legend>引用区块 - 默认风格</legend>
          </fieldset>

          <blockquote class="layui-elem-quote">这个貌似不用多介绍，因为你已经在太多的地方都看到</blockquote>

          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
            <legend>引用区块 - 一般风格</legend>
          </fieldset>

          <blockquote class="layui-elem-quote layui-quote-nm">
            猿强，则国强。国强，则猿更强！
            <br>——孟子（好囖。。其实这特喵的是我说的）
          </blockquote>

          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
            <legend>字段集区块</legend>
          </fieldset>

          <fieldset class="layui-elem-field">
            <legend>爱好</legend>
            <div class="layui-field-box">
              你可以在这里放任何内容，比如表单神马的
            </div>
          </fieldset>
          <br>
          <fieldset class="layui-elem-field layui-field-title">
            <legend>带标题的横线</legend>
          </fieldset>

          内容区域

          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
            <legend>分割线</legend>
          </fieldset>

          默认分割线
          <hr> 赤色分割线
          <hr class="layui-bg-red"> 橙色分割线
          <hr class="layui-bg-orange"> 墨绿分割线
          <hr class="layui-bg-green"> 青色分割线
          <hr class="layui-bg-cyan"> 蓝色分割线
          <hr class="layui-bg-blue"> 黑色分割线
          <hr class="layui-bg-black"> 灰色分割线
          <hr class="layui-bg-gray">

          <fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
            <legend>纯圆角</legend>
          </fieldset>

          <div class="layui-inline">
            <img src="http://cdn.layui.com/avatar/168.jpg?t=1490352249902" class="layui-circle">
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<script>
</script>

<style scoped>

</style>