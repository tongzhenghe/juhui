<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:106:"E:\web_server\PhpStudy\PHPTutorial\WWW\juhui\juhui\public/../application/admin\view\juhuiadmin\button.html";i:1533258940;}*/ ?>
<div class="layui-fluid">
  <div class="layui-row">
    <div class="layui-col-xs12">
      <div class="layui-card">
        <div class="layui-card-header">按钮-> 文档请参考：
          <a href="http://www.layui.com/doc/element/button.html" target="_blank">
              http://www.layui.com/doc/element/button.html
            </a>
        </div>
        <div class="layui-card-body">
          <fieldset class="layui-elem-field site-demo-button" style="margin-top: 30px;">
            <legend>按钮主题</legend>
            <div>
              <button class="layui-btn layui-btn-primary">原始按钮</button>
              <button class="layui-btn">默认按钮</button>
              <button class="layui-btn layui-btn-normal">百搭按钮</button>
              <button class="layui-btn layui-btn-warm">暖色按钮</button>
              <button class="layui-btn layui-btn-danger">警告按钮</button>
              <button class="layui-btn layui-btn-disabled">禁用按钮</button>
            </div>
          </fieldset>
          <fieldset class="layui-elem-field site-demo-button">
            <legend>按钮尺寸</legend>
            <div>
              <button class="layui-btn layui-btn-primary layui-btn-lg">大型按钮</button>
              <button class="layui-btn layui-btn-primary">默认按钮</button>
              <button class="layui-btn layui-btn-primary layui-btn-sm">小型按钮</button>
              <button class="layui-btn layui-btn-primary layui-btn-xs">迷你按钮</button>

              <br>

              <button class="layui-btn layui-btn-lg">大型按钮</button>
              <button class="layui-btn">默认按钮</button>
              <button class="layui-btn layui-btn-sm">小型按钮</button>
              <button class="layui-btn layui-btn-xs">迷你按钮</button>

              <br>

              <button class="layui-btn layui-btn-lg layui-btn-normal">大型按钮</button>
              <button class="layui-btn layui-btn-normal">默认按钮</button>
              <button class="layui-btn layui-btn-sm layui-btn-normal">小型按钮</button>
              <button class="layui-btn layui-btn-xs layui-btn-normal">迷你按钮</button>

              <br>

              <div style="width: 216px; margin: 0;">
                <!-- layui 2.2.5 新增 -->
                <button class="layui-btn layui-btn-fluid">流体按钮</button>
              </div>
            </div>
          </fieldset>
          <fieldset class="layui-elem-field site-demo-button">
            <legend>灵活的图标按钮（更多图标请阅览：文档-图标）</legend>
            <div>
              <button class="layui-btn"><i class="layui-icon"></i></button>
              <button class="layui-btn"><i class="layui-icon"></i></button>
              <button class="layui-btn"><i class="layui-icon"></i></button>
              <button class="layui-btn"><i class="layui-icon"></i></button>
              <button class="layui-btn"><i class="layui-icon"></i></button>
              <button class="layui-btn"><i class="layui-icon"></i></button>

              <br>

              <button class="layui-btn layui-btn-danger"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-danger"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-danger"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-danger"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-danger"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-danger"><i class="layui-icon"></i></button>

              <br>

              <button class="layui-btn layui-btn-primary layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-primary layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-primary layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-primary layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-primary layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-primary layui-btn-sm"><i class="layui-icon"></i></button>

              <button class="layui-btn layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-sm"><i class="layui-icon"></i></button>

              <button class="layui-btn layui-btn-normal layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-normal layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-normal layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-normal layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-normal layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-normal layui-btn-sm"><i class="layui-icon"></i></button>
            </div>
          </fieldset>
          <fieldset class="layui-elem-field site-demo-button">
            <legend>还可以是圆角按钮</legend>
            <div>
              <button class="layui-btn layui-btn-primary layui-btn-radius">原始按钮</button>
              <button class="layui-btn layui-btn-radius">默认按钮</button>
              <button class="layui-btn layui-btn-normal layui-btn-radius">百搭按钮</button>
              <button class="layui-btn layui-btn-warm layui-btn-radius">暖色按钮</button>
              <button class="layui-btn layui-btn-danger layui-btn-radius">警告按钮</button>
              <button class="layui-btn layui-btn-disabled layui-btn-radius">禁用按钮</button>
            </div>
          </fieldset>
          <fieldset class="layui-elem-field site-demo-button">
            <legend>风格混搭的按钮</legend>
            <div>
              <button class="layui-btn layui-btn-lg layui-btn-primary layui-btn-radius">大型加圆角</button>
              <a href="http://www.layui.com/doc/element/button.html" class="layui-btn" target="_blank">跳转的按钮</a>
              <button class="layui-btn layui-btn-sm layui-btn-normal"><i class="layui-icon"></i> 删除</button>
              <button class="layui-btn layui-btn-xs layui-btn-disabled"><i class="layui-icon"></i> 分享</button>
            </div>
          </fieldset>

          <fieldset class="layui-elem-field site-demo-button">
            <legend>按钮组</legend>
            <div class="layui-btn-group">
              <button class="layui-btn">增加</button>
              <button class="layui-btn ">编辑</button>
              <button class="layui-btn">删除</button>
            </div>
            <div class="layui-btn-group">
              <button class="layui-btn layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-sm"><i class="layui-icon"></i></button>
            </div>
            <div class="layui-btn-group">
              <button class="layui-btn layui-btn-primary layui-btn-sm">文字</button>
              <button class="layui-btn layui-btn-primary layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-primary layui-btn-sm"><i class="layui-icon"></i></button>
              <button class="layui-btn layui-btn-primary layui-btn-sm"><i class="layui-icon"></i></button>
            </div>
          </fieldset>


        </div>
      </div>
    </div>
  </div>
</div>


<script></script>

<style scoped>
  .site-demo-button {
    margin-bottom: 30px;
  }
  
  .site-demo-button div {
    margin: 20px 30px 10px;
  }
  
  .site-demo-button .layui-btn+.layui-btn {
    margin-left: 0;
  }
  
  .site-demo-button .layui-btn {
    margin: 0 7px 10px 0;
  }
  
  .layui-btn+.layui-btn {
    margin-left: 10px;
  }
</style>